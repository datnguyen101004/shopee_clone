# Kế hoạch triển khai cho agent nhận bàn giao

Các ô dưới đây chưa được thực hiện trong lần xuất tài liệu này. User muốn cả hai frame; không kết thúc ở danh sách mà bỏ editor.

## 1. Đối chiếu code và ranh giới

- [ ] Đọc README, UI-SPEC, IMPLEMENTATION, PROJECT-ADAPTATION và asset-resolution.json; mở hai screenshot và đọc AGENTS.md áp dụng.
- [ ] Kiểm tra routes list/view/edit/new, shell cha và các contracts hiện tại.
- [ ] Đối chiếu các khoảng cách nghiệp vụ trong IMPLEMENTATION; xác định phần có thể nối API ngay, phần chỉ là dữ liệu minh họa.
- [ ] Giới hạn theme xanh/radius mới vào hai màn hình, dùng Be Vietnam Pro hiện có; không đổi Storefront hoặc trang Seller khác ngoài phạm vi.

## 2. Shell dùng chung

- [ ] Áp dụng sidebar 260, header 80, body gutters 32, typography và profile theo Figma.
- [ ] Dùng navigation/session thật, giữ role/shop gate; không thêm sidebar thứ hai trong layout đã bọc.
- [ ] Tái sử dụng primitives; thêm variants/tokens có scope nếu thiếu, không override global brand.

## 3. Danh sách sản phẩm — 2:5

- [ ] Toolbar, CTA thêm sản phẩm, bảng 7 cột, thumbnail, tên/metadata, giá, tồn, badge, action.
- [ ] Nối filter và pagination với contract thật; không fake search toàn kho, SKU, tổng số hay page cuối.
- [ ] Giữ đủ lifecycle/moderation và các thông tin cần thiết hiện có; giữ confirmation và quyền xóa.
- [ ] Kiểm tra desktop, lỗi tải/empty, thao tác pending và list → edit/new.

## 4. Chi tiết / chỉnh sửa — 2:192

- [ ] Breadcrumb, cancel/save, gallery 420, card form 664 và vùng tabs.
- [ ] Giữ media upload/retry/remove, draft và trạng thái đang tải.
- [ ] Nối fields với model thật; giữ SKU chỉ đọc khi API chưa hỗ trợ, attribute brand hợp lệ, đơn vị và nhiều variants.
- [ ] Giữ category/lifecycle/moderation và phần nghiệp vụ chưa có trong frame; bố trí theo cùng ngôn ngữ thị giác.
- [ ] Chốt mô tả textarea, thông số theo category.attributes, đánh giá tổng quan + link đánh giá shop theo PROJECT-ADAPTATION.
- [ ] Kiểm tra lưu thành công/lỗi/validation và không hồi quy route xem chi tiết/tạo mới dùng chung component.

## 5. CSS và kiểm chứng tổng hợp

- [ ] Gỡ CSS/markup không còn consumer trong phạm vi đã refactor; kiểm tra selector động và thứ tự import.
- [ ] Chạy typecheck, lint và tests liên quan theo scripts thực tế; visual checks sau đợt thay đổi hoàn chỉnh.
- [ ] Đối chiếu cả hai trang desktop; kiểm tra adaptation 768 × 1024 và 360 × 800, không overflow toàn trang.
- [ ] Giữ accessible labels, focus, refs, semantics table/form/tabs/switch, data-testid và navigation.
- [ ] Báo kết quả thật, các chênh lệch thiết kế/nghiệp vụ và assets còn thiếu.

Không bắt buộc chạy toàn bộ suite sau mỗi file. Không sửa backend, mua thêm lượt MCP, đổi framework hoặc cài thư viện chỉ để hoàn thành hình thức của mẫu.

## 6. Áp dụng phần bổ sung theo project

- [ ] Tái sử dụng icon Lucide/assets đã đóng gói; media API và avatar initials; không cần tải SVG gốc.
- [ ] Hoàn thiện loaded-only filters + footer cursor theo nhãn đã chốt, async race protection và lỗi tải thêm.
- [ ] Giữ xóa mềm published/hidden/archived qua confirmation; không hạn chế sai vì tên hàm deleteDraft.
- [ ] Triển khai states/modal/focus/responsive theo PROJECT-ADAPTATION và đối chiếu STATE-PREVIEW.
